# sell-it
Old things selling app using React Native
