const colors = {
  danger: "#ef476f",
  warning: "#ffd166",
  success: "#06D6A0",
  primary: "#118ab2",
  secondary: "#073b4c",
  lightGray: "#D8D8D8",
  whiteSmoke: "#F5F5F5",
  dark: "#000",
  light: "#fff",
};

export default colors;
